module.exports = {
  rules: {
    'body-tense': [0, 'never', 0],
    lang: 'eng',
  },
  extends: ['@commitlint/config-angular'],
};
